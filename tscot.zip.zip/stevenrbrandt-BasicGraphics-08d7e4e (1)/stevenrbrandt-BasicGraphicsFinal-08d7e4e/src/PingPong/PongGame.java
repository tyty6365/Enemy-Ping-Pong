package PingPong;
import basicgraphics.BasicContainer;
import basicgraphics.BasicFrame;
import basicgraphics.Clock;
import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.SpriteSpriteCollisionListener;
import basicgraphics.Task;
import basicgraphics.examples.Bat;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.LinkedList;
import java.util.Random;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import basicflyer.Plasma;

public class PongGame {
	static GamePaddles left;
	static GamePaddles right;
	static GameBall b;
	static Tubes t;
	static Tubes t1;
	static Tubes t2;
	static Tubes t3;
	static ExtraBalls bb;
	static ExtraBalls ba;
	static ExtraBalls bc;
	static ExtraBalls bd;
	static ExtraBalls be;
	static ExtraBalls bg;
	static ExtraBalls bh;
	static ExtraBalls bi;
	static ExtraBalls bj;
	static GameScore a;
	static Enemy f;
	static Enemy2 ff;
	static int score1 = 0;
	static int score2 = 0;
	static stopWatch sw;
	static double INCR = Math.PI * 2 / 100.0;
	static int levelCounter = 1;
	final static BasicContainer bc2 = new BasicContainer();
	final static BasicContainer bc3 = new BasicContainer();
	public static void main(String[] args) throws IOException {
		int id = 1; // set to one for a test right now
		int yVelocity;// how fast the ball will move
		int speed = 10;
		SpriteComponent sc = new SpriteComponent();
		System.out.println("Enjoy the Game");
		System.out.println("The game is now running...");
		System.out.println("Welcome to Enemy Ping Pong, distract your opponent by moving the sprite on the board, but be careful to not get distracted yourself!");
		System.out.println("Please refer to any of the instructions buttons if you need further assiatnce!");
        final ReusableClip clip = new ReusableClip("beep.wav");
        final ReusableClip clip2 = new ReusableClip("die.wav");
		final BasicFrame bf = new BasicFrame("Enemy Ping Pong");
		final Container content = bf.getContentPane();
		final CardLayout cards = new CardLayout();
		content.setLayout(cards);
		BasicContainer bc1 = new BasicContainer();
		content.add(bc1, "Enemy Ping Pong");
		content.add(bc2, "Game");
		content.add(bc3, "Instructions");
		JButton jb3 = new JButton("Click Here for Enenmy Ping Pong Game Info !"); 
		JButton jb4 = new JButton("Click Here for Ball Info !");
		JButton jb5 = new JButton("Click Here for Paddle Info !");
		JButton jb6 = new JButton("Click Here for Enemy Info !");
		JButton jb7 = new JButton("Click Here for Clock Info !");
		JButton jb8 = new JButton("Click Here for Shooting Ball Info !");
		JButton jb9 = new JButton("Click Here for Score Info !");
		JButton jb10 = new JButton("Click Here for Enemy Ball Info !");
		final SpriteComponent da = new SpriteComponent() {
			public void paintBackground(Graphics g) {
				Dimension d = getSize();
				g.setColor(Color.yellow);
				g.fillRect(0, 0, d.width, d.height);
				final int NUM_DOTS = 1000;
				Random rand = new Random();
				rand.setSeed(0);
				g.setColor(Color.blue);
				for (int i = 0; i < NUM_DOTS; i++) {
					int diameter = rand.nextInt(2) + 1;
					int xpos = rand.nextInt(d.width);
					int ypos = rand.nextInt(d.height);
					g.fillOval(xpos, ypos, diameter, diameter);
				}}
		};
		da.setPreferredSize(new Dimension(800, 400));
		String[][] splashLayout = { { "Title", "Title" }, { "Button", "Button" }, { "Second Button", "Second Button" },
				{ "TextBox", "name" }, 
				{ "TextBox2", "name2" }, 
				{ "Title2", "Title2" }, 
				{ "Btn3","Btn4"}, 
				{ "Btn5", "Btn6" },  
				{ "Btn7", "Btn8"}, 
				{ "Btn9", "Btn10"}};
		bc1.setStringLayout(splashLayout);
		bc1.add("Title", new JLabel("Welcome to Enemy Ping Pong"));
		bc1.add("TextBox", new JLabel("Player 1 Name:"));
		bc1.add("TextBox2", new JLabel("Player 2 Name:"));
		bc1.add("name", new JTextField("Your Name Here"));
		bc1.add("name2", new JTextField("Your Name Here"));
		bc1.add("Title2", new JLabel("Created by Tyler Scott"));
		bc1.add("Btn3", jb3);
		bc1.add("Btn4", jb4);
		bc1.add("Btn5", jb5);
		bc1.add("Btn6", jb6);
		bc1.add("Btn7", jb7);
		bc1.add("Btn8", jb8);
		bc1.add("Btn9", jb9);
		bc1.add("Btn10", jb10);
		final JPanel jp = new JPanel();
		final CardLayout cards2 = new CardLayout();
		jp.setLayout(cards);
		JButton jstart = new JButton("Click Here to Begin");
		jstart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cards.show(content, "Game");
				bf.jf.requestFocus();
				Clock.start(10); // Start the timer
			}
		});
		bc1.add("Button", jstart);
		String[][] layout = { { "Ping Pong" }, { "Instructions" } };
		bc2.setStringLayout(layout);
		bc3.setStringLayout(layout);
		bc2.add("Ping Pong", da);
		
		BasicContainer card1 = new BasicContainer();
		String[][] layout2 = { { "Click", "Bat" } };
		JButton click2 = new JButton("click");
		BasicContainer card2 = new BasicContainer();
		card2.setStringLayout(layout2);
		card2.add("Click", click2);
		jp.add(card1, "Panel 1");
		jp.add(card2, "Panel 2");
		jb3.addActionListener(new ActionListener() { //Ping Pong Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
									{ "Line2" },
									{"Line3"},
									{"Line4"},
									{"Line5"},
									{"Line6"},
									{"Line7"}};
				JButton close = new JButton("close");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("Instructions: Welcome to enemy ping pong, play alone or with a friend! "));
				bc.add("Line2", new JLabel("Player(s) in the game can earn enemies and take away points."));
				bc.add("Line3", new JLabel("Be careful to not get distracted yourself with the red balls constanlty flying."));
				bc.add("Line4", new JLabel("There are three levels."));
				bc.add("Line5", new JLabel("The winner is determined by whoever scores 5 points first, then 10, and finally 15."));
				bc.add("Line6", new JLabel("																																"));
				bc.add("Line7", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb4.addActionListener(new ActionListener() { //Ball Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
									{ "Line2" },
									{"Line3"},
									{"Line4"},
									{"Line5"},
									{"Line6"}};
				JButton close = new JButton("close");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("Instructions: There will be a black ball on the ping pong table."));
				bc.add("Line2", new JLabel("The black ball will be the main used throughout the game to earn one point for each paddle."));
				bc.add("Line3", new JLabel("There will be red 'DISTRACTION' balls constantly moving around the ping pong table to distract players from earning points."));
				bc.add("Line4", new JLabel("Pay attention to the correct ball, as it also speeds up after each time it hits the paddles!"));
				bc.add("Line5", new JLabel("																																"));
				bc.add("Line6", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb5.addActionListener(new ActionListener() { //Paddle Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = 	{{ "Line1" },
										{ "Line2" },
										{"Line3"},
										{"Line4"},
										{"Line5"},
										{"Line6"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("Instructions: There are two paddles on the enemy ping pong board."));
				bc.add("Line2", new JLabel("The red paddle is the left paddle."));
				bc.add("Line3", new JLabel(" The blue paddle is the right paddle."));
				bc.add("Line4", new JLabel(" After the black ball hits the paddle once a point will be awarded to the left/right paddle."));
				bc.add("Line5", new JLabel("																																"));
				bc.add("Line6", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb6.addActionListener(new ActionListener() { //Enemy Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
						{ "Line2" },
						{"Line3"},
						{"Line3"},
						{"Line4"},
						{"Line5"},
						{"Line6"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);																																
				bc.add("Line1", new JLabel(" Instructions: The enemies move at a constant motion throughout the game.			"));
				bc.add("Line2", new JLabel("    The left player can use keys 'Q' and 'A' to turn their enemy (ANT)."));
				bc.add("Line3", new JLabel("    The right player can use the keys 'UP' and 'DOWN' to turn their enemy (SPACESHIP).            "));
				bc.add("Line4", new JLabel("    Be careful as the enemy can wrap around the screen and touch your paddle and take away 1 point!         "));
				bc.add("Line5", new JLabel("																																"));
				bc.add("Line6", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb7.addActionListener(new ActionListener() { // Clock Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
						{ "Line2" },
						{"Line3"},
						{"Line3"},
						{"Line4"},
						{"Line5"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("Instructions: A timer will be presented before the game begins."));
				bc.add("Line2", new JLabel(" Move the timer over and start it to see how long you or your opponent have been playing the game."));
				bc.add("Line3", new JLabel("Restart it if you would like!"));
				bc.add("Line4", new JLabel("																																"));
				bc.add("Line5", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb8.addActionListener(new ActionListener() { // Shooting Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
						{ "Line2" },
						{"Line3"},
						{"Line4"},
						{"Line5"},
						{"Line6"},
						{"Line7"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("The enemies can shoot balls by pressing the keys associated with each enemy."));
				bc.add("Line2", new JLabel("The left/red paddle's enemy can shoot balls by using the 'Z' key"));
				bc.add("Line3", new JLabel("The right/blue paddle's enemy can shoot balls by using the 'M' key"));
				bc.add("Line4", new JLabel("When the 'Z' key is pressed the enemy will produce a 'die' sound."));
				bc.add("Line5", new JLabel("When the 'M' key is pressed the enemy will produce a 'beep' sound."));
				bc.add("Line6", new JLabel("Let your opponent know you're coming by shooting out red balls ! "));
				bc.add("Line7", new JLabel("																																"));

				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();
					}
				});
				jd.pack();
				jd.setVisible(true);
			}
		});
		jb9.addActionListener(new ActionListener() { //Score Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
						{ "Line2" },
						{"Line3"},
						{"Line4"},
						{"Line5"},
						{"Line6"},
						{"Line7"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("The score will be automatically calculated and updated."));
				bc.add("Line2", new JLabel("The updated score will be posted at the top of the ping pong table."));
				bc.add("Line3", new JLabel("A point will be awarded each time the ping pong ball bounces off the paddle."));
				bc.add("Line4", new JLabel("A point will be taken away if the opposing enemy touches the opposing paddle."));
				bc.add("Line5", new JLabel("No points will be deducted or rewarded if the ball passes the paddles."));		
				bc.add("Line6", new JLabel("																																"));
				bc.add("Line7", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();}
				});
				jd.pack();
				jd.setVisible(true);}
		});
		jb10.addActionListener(new ActionListener() { //Extra Balls Button
			@Override
			public void actionPerformed(ActionEvent e) {
				final JDialog jd = new JDialog(BasicFrame.getFrame().jf, "Instructions", Dialog.ModalityType.APPLICATION_MODAL);
				BasicContainer bc = new BasicContainer();
				String[][] layout = {{ "Line1" },
						{ "Line2" },
						{"Line3"},
						{"Line4"},
						{"Line5"},
						{"Line6"},
						{"Line7"}};
				JButton close = new JButton("close");
				final JTextField input = new JTextField("");
				bc.setStringLayout(layout);
				bc.add("Line1", new JLabel("There will be extra balls constanlty flying on the 'Ping Pong Table.'"));
				bc.add("Line2", new JLabel("They are used as distractions to make the game more challenging and fun!"));
				bc.add("Line3", new JLabel("These balls do not effect the score by deducting or adding points."));
				bc.add("Line4", new JLabel("Try not to get the enemy balls confused with the main black ball."));
				bc.add("Line5", new JLabel("Keep your focus and try your best to follow the black ball !"));		
				bc.add("Line6", new JLabel("																																"));
				bc.add("Line7", new JLabel("																																"));
				jd.add(bc);
				close.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						jd.dispose();}
				});
				jd.pack();
				jd.setVisible(true);}
		});
		bf.show();
		left = new GamePaddles(da, Color.red, 0, 200, 1);
		right = new GamePaddles(da, Color.blue, 750, 200, 2);
		b = new GameBall(da);
		t = new Tubes(da, Color.black, 0, 0);
		t1 = new Tubes(da, Color.black, 779, 380);
		t2 = new Tubes(da, Color.black, 779, 0);
		t3 = new Tubes(da, Color.black, 0, 380);
		bb = new ExtraBalls(da);
		ba = new ExtraBalls(da);
		bc = new ExtraBalls(da);
		bd = new ExtraBalls(da);
		be = new ExtraBalls(da);
		bg = new ExtraBalls(da);
		bh = new ExtraBalls(da);
		bi = new ExtraBalls(da);
		bj = new ExtraBalls(da);
		a = new GameScore(da);
		sw = new stopWatch();
		f = new Enemy(da);
		f.is_visible = false;
		ff = new Enemy2(da);
		ff.is_visible = false;
		if (GameScore.player1 >= 2) {
			f.setVelX(1);
			f.is_visible = true;
		}
		if (GameScore.player2 >= 2) {
			ff.setVelX(1);
			ff.is_visible = true;
		}
		Task newTaskKeyTwo = new Task() {
			@Override
			public void run() {
				if (bf.isKeyHeld('Q')) {
					f.turn(INCR);
				} else if (bf.isKeyHeld('A')) {
					f.turn(-INCR);
				} else if (bf.isKeyHeld(KeyEvent.VK_Z)) {
					EnemyShooter es = new EnemyShooter(da);
					es.setVelX(f.getVelX() * 2);
					es.setVelY(f.getVelY() * 2);
					es.setCenterX(f.centerX());
					es.setCenterY(f.centerY());
                    clip.play();
				}
				if (bf.isKeyHeld(KeyEvent.VK_LEFT)) {
					ff.turn(INCR);
				} else if (bf.isKeyHeld(KeyEvent.VK_RIGHT)) {
					ff.turn(-INCR);
				} else if (bf.isKeyHeld(KeyEvent.VK_M)) {
					EnemyShooter ec = new EnemyShooter(da);
					ec.setVelX(ff.getVelX() * 2);
					ec.setVelY(ff.getVelY() * 2);
					ec.setCenterX(ff.centerX());
					ec.setCenterY(ff.centerY());
					clip2.play();
				}
			}
		};
		Clock.addTask(newTaskKeyTwo);
		Task newTaskKey = new Task() {
			@Override
			public void run() {
				if (bf.isKeyHeld('W')) {
					System.out.println("Up");
					if (left.getY() <= 0) {
						return;
					}
					left.setY(left.getY() - 10);
					left.move();
				}
				if (bf.isKeyHeld('S')) {
					System.out.println("down");
					if (left.getY() >= 300) {
						return;
					}
					left.setY(left.getY() + 10);
					left.move();
				}
				if (bf.isKeyHeld(KeyEvent.VK_UP)) {
					System.out.println("Up");
					if (right.getY() <= 0) {
						return;
					}
					right.setY(right.getY() - 10);
					right.move();
				}
				if (bf.isKeyHeld(KeyEvent.VK_DOWN)) {
					System.out.println("down");
					if (right.getY() >= 300) {
						return;
					}
					right.setY(right.getY() + 10);
					right.move();
				}
			}
		};
		Clock.addTask(newTaskKey);
		Clock.addTask(da.moveSprites());
		da.addSpriteSpriteCollisionListener(GamePaddles.class, GameBall.class,
				new SpriteSpriteCollisionListener<GamePaddles, GameBall>() {
					public void collision(GamePaddles gp, GameBall b) {
						if (gp.player == 1) {
							System.out.println("left paddle collided with ball");
							score1++;
							if (score1 >= 2) {
								f.setVelX(1);
								f.is_visible = true;
							}
							setScore();
							System.out.println("Paddle1:" + GameScore.player1);
						}
						if (gp.player == 2) {
							System.out.println("right paddle collided with ball");
							score2++;
							if (score2 >= 2) {
								ff.setVelX(1);
								ff.is_visible = true;
							}
							setScore();
							System.out.println("Paddle2:" + GameScore.player2);
						}
						if (a.player1 % 5 == 0 || a.player2 % 5 == 0) {
							b.xVelocity++;
							b.yVelocity++;
						}
						levelCheck(levelCounter, da); // for levelCheck method
						b.BallCollided(gp);
					}
				});
		da.addSpriteSpriteCollisionListener(GamePaddles.class, Enemy.class,
				new SpriteSpriteCollisionListener<GamePaddles, Enemy>() {// this one is for the red/left paddle
					public void collision(GamePaddles gp, Enemy e) {
						if (gp.player == 2) {
							System.out.println("right paddle collided with ball");
							if (GameScore.player2 != 0) {
								score2--;
							}
							setScore();
							System.out.println("Enemy Paddle2:" + GameScore.player2);
							new GameScore(PongGame.GetSC());
						}
					}
				});
		da.addSpriteSpriteCollisionListener(GamePaddles.class, Enemy2.class,
				new SpriteSpriteCollisionListener<GamePaddles, Enemy2>() {// this one is for the blue/right paddle
					@Override
					public void collision(GamePaddles sp1, Enemy2 sp2) {
						if (sp1.player == 1) {
							if (GameScore.player1 != 0) {
								score1--;
							}
							setScore();
							System.out.println("Enemy Paddle1:" + GameScore.player1);
							new GameScore(PongGame.GetSC());
						}
					}
				});
	}
	public static void collisionCheck() {
		if (left.checkBallCollision(b) == true) {
			a.player1++;
			if (a.player1 % 5 == 0) {
				b.xVelocity++;
				b.yVelocity++;
				b.setVelocity();
			}
		}
		if (right.checkBallCollision(b) == true) {
			a.player2++;
			if (a.player2 % 5 == 0) {
				b.xVelocity++;
				b.yVelocity++;
				b.setVelocity();
			}
		}
		if (f.checkBallCollision(b) == true) {
			System.exit(1);
		}
	}

	public static void levelCheck(int level, SpriteComponent da) { // method shows messages for levels //HELP: how do i get the messages to show correctly
		switch(levelCounter) {
		case 1: 
			if (score1 == 5) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 1 Winner: Player 1");
		}
		else if (score2 == 5) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 1 Winner: Player 2");
		}
		break;
		
		case 2: 
			if (score1 == 10) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 2 Winner: Player 1");
		}
		else if (score2 == 10) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 2 Winner: Player 2");
		}
		break;
		
		case 3:
			if (score1 == 15) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 3 Winner: Player 1");
		}
		else if (score2 == 15) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 3 Winner: Player 2");
		}
		break;
		case 4:
			if (score1 == 20) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 4 Winner: Player 1. GAME OVER!");
			System.exit(level);
		}
		else if (score2 == 20) {
			levelCounter++;
			JOptionPane.showMessageDialog(da, "Level 4 Winner: Player 2. GAME OVER!");
			System.exit(level);
		}
		break;
		}
	}

	public static void setScore() {
		GameScore.player1 = score1;
		GameScore.player2 = score2;
		a.setPicture(GameScore.MakeScore());
	}

	public static SpriteComponent GetSC() {
		SpriteComponent da = new SpriteComponent();
		return da;
	}

	public void run() {// game loop, similar to mine craft
		long lastTime = System.nanoTime();
		double amountOfTicks = 60.0;
		double ns = 1000000000 / amountOfTicks;
		double delta = 0;
		while (true) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			if (delta >= 1) { // re-does everything if game restarts
				delta--;
			}
		}
	}

	byte[] buf;
	SourceDataLine sourceLine;
	static Thread thread;
	static boolean running = false;
	static LinkedList<ReusableClip> queue = new LinkedList<>();
	public static boolean verbose = false;
	static {
		thread = new Thread(() -> {
		});
		thread.start();
	}

	private static synchronized ReusableClip dequeue() {
		if (queue.size() == 0)
			return null;
		else
			return queue.removeLast();
	}

	private static synchronized void done() {
		running = false;
	}

	private static synchronized void enqueue(basicgraphics.sounds.ReusableClip pongGame) {
		queue.addLast(pongGame);
		if (!running) {
			try {
				thread.join();
			} catch (InterruptedException ex) {
			}
			running = true;
			thread = new Thread(() -> {
				while (true) {
					ReusableClip clip = dequeue();
					if (clip == null)
						break;
					try {
						clip.playNow();
						if (clip.looping)
							enqueue(clip);
					} catch (Throwable e) {
						if (verbose)
							e.printStackTrace();
						else
							System.err.println("endclip: " + e);
					}
				}
				done();
			});
			thread.start();
		}
	}
	private static URI getURI(String name) {
		try {
			return ReusableClip.class.getResource(name).toURI();
		} catch (URISyntaxException ex) {
			return null;}}
	public void ReusableClip(String name) {}
	String name = "";

	public void ReusableClip(URI uri) {
		this.name = uri == null ? "?" : uri.getPath();
		try {
			if (verbose)
				System.out.println("loading sound: " + uri);
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(uri.toURL());
			AudioFormat audioFormat = audioStream.getFormat();
			DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
			sourceLine = (SourceDataLine) AudioSystem.getLine(info);
			sourceLine.open(audioFormat);
			long nbytes = audioStream.getFrameLength();
			while (nbytes % 4 != 0)
				nbytes++;
			buf = new byte[(int) nbytes];
			audioStream.read(buf);
		} catch (Exception ex) {
			if (verbose)
				ex.printStackTrace();
			else
				System.err.println(ex);
		}
	}

	public void playNow() {
		if (verbose)
			System.out.println("playing sound: " + name);
		sourceLine.start();
		sourceLine.write(buf, 0, buf.length);
		sourceLine.drain();
		sourceLine.flush();
	}

	public synchronized void play() {
		looping = false;
	}

	volatile boolean looping = false;

	public synchronized void loop() {
		looping = true;
	}

	public void stop() {
		looping = false;
	}

	public static void main1(String[] args) throws Exception {
		verbose = true;
		BasicFrame bf = new BasicFrame("title");
		bf.show();
		ReusableClip clip1 = new ReusableClip("die.wav");
		ReusableClip clip2 = new ReusableClip("beep.wav");
		long t1 = System.currentTimeMillis();
		clip1.loop();
		clip2.loop();
		Thread.sleep(5000);
		clip1.stop();
		clip2.stop();
		long t2 = System.currentTimeMillis();
		System.out.printf("time=%d%n", (t2 - t1));
		bf.dispose();
		KeyListener kl = new KeyListener() {
			@Override
			public void keyTyped(KeyEvent e) {
				System.out.println("Keys are in use, DO NOT DISRUPT THE GAME");
			}

			@Override
			public void keyPressed(KeyEvent e) {
				System.out.println("Keys are in use, DO NOT DISRUPT THE GAME");
			}

			@Override
			public void keyReleased(KeyEvent e) {
				System.out.println("Keys are in use, DO NOT DISRUPT THE GAME");
			}
		};
		BasicFrame f = new BasicFrame("PingPong");
		KeyListener k1 = null;
		f.addKeyListener(k1);
		MouseListener ml = new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("click");
			}

			@Override
			public void mousePressed(MouseEvent e) {
				System.out.println("click");
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				System.out.println("click");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				System.out.println("click");
			}

			@Override
			public void mouseExited(MouseEvent e) {
				System.out.println("click");
			}
		};}}