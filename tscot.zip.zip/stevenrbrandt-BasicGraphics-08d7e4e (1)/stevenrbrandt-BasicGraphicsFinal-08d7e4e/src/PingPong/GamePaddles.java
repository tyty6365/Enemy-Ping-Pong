package PingPong;
import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import static javax.swing.Spring.height;
import static javax.swing.Spring.width;
public class GamePaddles extends Sprite{
	int x;
	int y;
    int id;//Identifies the players
    int yVelocity;//how fast the ball will move 
    int speed = 10;
    int width;
    int height;
    int points = 0;
    private Picture p;
    int player;
    Color color;
    public GamePaddles(SpriteComponent sc, Color color, int x, int y, int playerNum) {
        super(sc);
        this.setY(y);
        this.setX(x);
        this.color = color;
        this.player = playerNum;
        setPicture(MakePaddles(color));}
    public static Picture MakePaddles(Color color) {
        BufferedImage im = BasicFrame.createImage(50, 100);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillRect(0, 0, 50, 100);
		return new Picture(im);}
    public void setYDirection(int yDirection){
    	System.out.println(yDirection);
    	setVelY(yDirection);
    	yVelocity = yDirection;}
    public void move() {}
    public Rectangle getBounds() {
    	Rectangle rect = this.getSpriteComponent().getBounds();
		return rect;
    }
    public boolean checkBallCollision(GameBall b) { 
    	Rectangle paddleRect = getBounds();
    	Rectangle ballRect = b.getBounds(); 
    	if(paddleRect.intersects(ballRect)) {
    		return true;
    		}else{
    			return false;}}}