package PingPong;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;

import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
public class GameScore extends Sprite{
    static int GAME_WIDTH = 800;
    static int GAME_HEIGHT = 400;
    public static int player1 = 0; //holds score of player1
    public static int player2 = 0; //holds score of player2
    public static String p1= "PLAYER 1";
    public static String p2= "PLAYER 2";
    static Graphics g;
    GameScore(SpriteComponent sc){
    	super(sc);
        setPicture(MakeScore());
        //setPicture(MakeName());
    }
    public static Picture MakeScore() {
    	BufferedImage im = BasicFrame.createImage(800, 400);
    	g = im.getGraphics();
        g.setColor(Color.black);
    	g.setFont(new Font("Consolas",Font.ROMAN_BASELINE,70));
    	g.drawLine(GAME_WIDTH/2, 0, GAME_WIDTH/2, GAME_HEIGHT);//draws line down the center of table
    	g.drawString(String.valueOf(player1/10)+String.valueOf(player1%10),(GAME_WIDTH/2)-85, 50); //adjusts score for p1
    	g.drawString(String.valueOf(player2/10)+String.valueOf(player2%10),(GAME_WIDTH/2)+20, 50); //adjusts score for p2
		return new Picture(im);}
    private void delay() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException ex) {}}
    public String getValue(BasicFrame bf, String txt) {
        delay();
        Component c = bf.getComponent(txt);
        if(c instanceof JLabel) {
            return ((JLabel) c).getText();
        } else if(c instanceof JTextArea) {
            return ((JTextArea) c).getText();
        } else if(c instanceof JTextComponent) {
            return ((JTextComponent) c).getText();}
        throw new Error("Not apart of my text");}
    public static void drawScore() {}}