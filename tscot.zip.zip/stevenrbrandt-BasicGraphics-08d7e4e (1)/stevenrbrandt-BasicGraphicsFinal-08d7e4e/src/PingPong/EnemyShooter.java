package PingPong;
import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
public class EnemyShooter extends Sprite{
	    public static Picture makeBall(Color color, int size) {
	        Image im = BasicFrame.createImage(size, size);
	        Graphics g = im.getGraphics();
	        g.setColor(color);
	        g.fillOval(0, 0, size, size);
	        return new Picture(im);
	    }
	    public EnemyShooter(SpriteComponent sc) {
	        super(sc);
	        setPicture(makeBall(Color.red, 10));
	    }
	    public void processEvent(SpriteCollisionEvent se) {
	        setActive(false);}}