package PingPong;
import basicgraphics.BasicFrame;
import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyListener;
import java.util.Random;
public class GameBall extends Sprite{
	public Picture basePic;
    SpriteComponent sc;
    int count = 0;
    Random random;//instance of the random class
    private Picture p;
    public double xVelocity = 1;
    public double yVelocity = 1;
    public static Picture makeBall(Color color, int size) {
    	Image im = BasicFrame.createImage(20, 20);
    	Graphics g = im.getGraphics();
    	g.setColor(color);
    	g.fillOval(0, 0, 20, 20);
    	return new Picture(im);}
    public GameBall(SpriteComponent sc) {
        super(sc);
        setPicture(makeBall(Color.black, 10));
        setX(nextDoubleBetween(50d,750d));
        setY(nextDoubleBetween(50d,350d));
        setVelocity();}
    public static double nextDoubleBetween(double min, double max) {
        return new Random().doubles(min, max).limit(1).findFirst().getAsDouble();
    }
    public void processEvent(SpriteCollisionEvent ce) {
    	SpriteComponent sc = getSpriteComponent();
    	if (ce.eventType == CollisionEventType.WALL) {
            if (ce.xlo) {
                setVelX(Math.abs(getVelX()));}
            if (ce.xhi) {
                setVelX(-Math.abs(getVelX()));}
            if (ce.ylo) {
                setVelY(Math.abs(getVelY()));}
            if (ce.yhi) {
                setVelY(-Math.abs(getVelY()));
            }}
    	else {
    		System.out.print("collided with something else");
    	}
    	return;}
	public Rectangle getBounds() {
		Rectangle rect = this.getSpriteComponent().getBounds();
		return rect;
	}
	public void BallCollided(GamePaddles gp) {
		double xVel = getVelX();
		double yVel = getVelY();
		if (gp.player == 1) {
			setVelX(xVelocity);
		} else if (gp.player == 2) {
			setVelX(-xVelocity);}}
	public void setVelocity() {
		setVelX(xVelocity);
        setVelY(yVelocity);}}