package PingPong;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
public class Tubes extends Sprite {
		int id;
		int x;
		int y;
		int yVelocity;
		private Picture p;
		Color color;
	public Tubes(SpriteComponent sc, Color color ,int x, int y) {
		super(sc);
		this.y=y;
		this.color = color;
		setPicture(MakeTubes(color,x, this.y));}
	public static Picture MakeTubes(Color color, int x, int y) {
		BufferedImage im = BasicFrame.createImage(800,400);
		Graphics g = im.getGraphics();
		g.setColor(color);
		g.fillRect(x, y, 20, 20);
		return new Picture(im);} 
	   public void setYDirection(int yDirection) {
	    	yVelocity = yDirection;} 
	    public void move(double incr) {	
			y= y+yVelocity;
			setPicture(MakeTubes(this.color, x, this.y));}}