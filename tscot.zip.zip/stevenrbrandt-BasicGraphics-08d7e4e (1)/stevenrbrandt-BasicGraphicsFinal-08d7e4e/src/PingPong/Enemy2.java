package PingPong;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JFrame;
public class Enemy2 extends Sprite {
	int x;
	int y;
	int width;
	int height;
    public Picture initialPic;
    public Enemy2(SpriteComponent sc) {
		super(sc);
        initialPic = new Picture("mfalcon.png");
        setPicture(initialPic);
        Dimension d = sc.getSize();
        setX(d.width/2);
        setY(d.height/2);
        setVelX(0);
        setVelY(0);}
    public void turn(double incr) {
        double heading = Math.atan2(getVelY(),getVelX());
        heading += incr;
        setVelY(Math.sin(heading));
        setVelX(Math.cos(heading));
        setPicture(initialPic.rotate(heading));}
    public void processEvent(SpriteCollisionEvent se) {
        SpriteComponent sc = getSpriteComponent();
        if (se.xlo) {
            setX(sc.getSize().width-getWidth());
        }
        if (se.xhi) {
            setX(0);
        }
        if (se.ylo) {
            setY(sc.getSize().height-getHeight());
        }
        if (se.yhi) {
            setY(0);}}
    public Rectangle getBounds() {
    	Rectangle rect = this.getSpriteComponent().getBounds();
		return rect;
    }
    public boolean checkBallCollision(GameBall b) { 
    	Rectangle enemy2Rect = getBounds();
    	Rectangle ballRect = b.getBounds();
    	if(enemy2Rect.intersects(ballRect)) {
    		return true;
    		}
    	else {
    		return false;
    	}}}